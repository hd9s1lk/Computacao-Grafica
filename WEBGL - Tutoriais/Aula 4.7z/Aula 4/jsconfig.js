{
    "typeAcquisition": {
        "include": [
            "three"
        ]
    }
}
   